import pyttsx3
import speech_recognition as sr
import datetime
import wikipedia
import webbrowser
import os
import requests

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)
engine.setProperty('rate', 150)

def speak(text):
    engine.say(text)
    engine.runAndWait()

def wish_me():
    hour = datetime.datetime.now().hour
    if 0 <= hour < 12:
        return "Good Morning!"
    elif 12 <= hour < 18:
        return "Good Afternoon!"
    else:
        return "Good Evening!"

def process_command(query):
    query = query.lower()

    if 'wikipedia' in query:
        query = query.replace("wikipedia", "")
        result = wikipedia.summary(query, sentences=2)
        return f"According to Wikipedia: {result}"

    elif 'youtube' in query:
        webbrowser.open("https://www.youtube.com")
        return "Opening YouTube..."

    elif 'google' in query:
        webbrowser.open("https://www.google.com")
        return "Opening Google..."

    elif 'weather' in query:
        city = "pune"
        api_key = 'your_api_key_here'
        url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"
        response = requests.get(url)
        data = response.json()
        if 'main' in data:
            temp = data['main']['temp']
            desc = data['weather'][0]['description']
            return f"In {city}, it's {temp}°C with {desc}."
        else:
            return "Weather information not available."

    elif 'time' in query:
        strTime = datetime.datetime.now().strftime("%H:%M:%S")
        return f"The time is {strTime}"

    elif 'stop' in query:
        return "Hope I could help you."

    else:
        return "Sorry, I didn't understand that."