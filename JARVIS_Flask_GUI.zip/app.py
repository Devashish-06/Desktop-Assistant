from flask import Flask, render_template, request, jsonify
from jarvis_core import speak, wish_me, process_command

app = Flask(__name__)

@app.route('/')
def index():
    greeting = wish_me()
    speak(greeting)
    return render_template('index.html', greeting=greeting)

@app.route('/ask', methods=['POST'])
def ask():
    query = request.form['query']
    response = process_command(query)
    speak(response)
    return jsonify({'response': response})

if __name__ == "__main__":
    app.run(debug=True)